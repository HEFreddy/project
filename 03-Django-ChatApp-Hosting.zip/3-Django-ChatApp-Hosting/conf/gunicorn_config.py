command = '/home/junus91/projects/Django-ChatApp'
pythonpath = '/home/junus91/projects/Django-ChatApp'
bind = '10.156.0.2:8000'
workers = 3
